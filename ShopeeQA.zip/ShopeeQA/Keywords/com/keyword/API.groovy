package com.keyword

import org.apache.http.client.methods.RequestBuilder

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.FormDataBodyParameter
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.RestRequestObjectBuilder
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import groovy.json.JsonSlurper
import internal.GlobalVariable
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response

public class API {
	
	@Keyword
	public static Object GetFullResponseJSON (String EndPoint, String action, String bodyParam, String contentType, String Authorization, String Cookie) {
		String APIURL = EndPoint
		def builder = new RestRequestObjectBuilder()
		ArrayList defaultHeaders
		TestObjectProperty headerContent
		TestObjectProperty headerAuth
		TestObjectProperty headerCookie
		boolean cont = false
		boolean auth = false
		boolean cook = false

		if (contentType.size() > 0) {
			cont = true
		}

		if (Authorization.size() > 0) {
			auth = true
		}

		if (Cookie.size() > 0) {
			cook = true
		}

		if (cont) {
			headerContent = new TestObjectProperty("Content-Type", ConditionType.EQUALS, contentType)
		}

		if (auth) {
			headerAuth = new TestObjectProperty("Authorization", ConditionType.EQUALS, Authorization)
		}

		if (cook) {
			headerCookie = new TestObjectProperty("Cookie", ConditionType.EQUALS, Cookie)
		}

		if ((cont) && (auth) && (cook)) {
			defaultHeaders = Arrays.asList(headerContent, headerAuth, headerCookie)

		} else if ((cont) && (auth) && (!cook)) {
			defaultHeaders = Arrays.asList(headerContent, headerAuth)

		} else if ((cont) && (!auth) && (cook)) {
			defaultHeaders = Arrays.asList(headerContent, headerCookie)

		} else if ((!cont) && (auth) && (cook)) {
			defaultHeaders = Arrays.asList(headerAuth, headerCookie)

		} else if ((cont) && (!auth) && (!cook)) {
			defaultHeaders = Arrays.asList(headerContent)

		}

		RequestObject request = new RestRequestObjectBuilder()
				.withRestUrl(APIURL)
				.withHttpHeaders(defaultHeaders)
				.withRestRequestMethod(action)
				.withTextBodyContent(bodyParam)
				.build()

		ResponseObject response = WS.sendRequest(request)

		if (response.getStatusCode ()!=200) {
			KeywordUtil.markFailedAndStop('Failed, error code '+response.getStatusCode())
		}

		return response.getResponseBodyContent()
	}
	

}